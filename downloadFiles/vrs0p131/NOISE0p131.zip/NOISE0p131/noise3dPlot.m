function h = noise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% NOISE3DPLOT Draw a 3D or contour plot for the relevant noise model.
%
%	Description:
%	h = noise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	noise3dPlot.m version 1.5


functionName = [noise.type 'Noise3dPlot'];
if exist(functionName) == 2
  fhandle = str2func(functionName);
  h = fhandle(noise, plotType, CX, CY, CZ, CZVar, varargin{:});
end

