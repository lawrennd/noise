function h = gaussianNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% GAUSSIANNOISE3DPLOT Draw a 3D or contour plot for the Gassian noise model.
%
%	Description:
%	h = gaussianNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	gaussianNoise3dPlot.m version 1.4


CZ = (CZ+noise.bias);
fhandle = str2func(plotType);
h = fhandle(CX, CY, CZ, varargin{:});
