function noise = cmpndNoiseExpandParam(noise, params)

% CMPNDNOISEEXPANDPARAM Expand probit noise structure from param vector.
%
% noise = cmpndNoiseExpandParam(noise, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% cmpndNoiseExpandParam.m version 1.2





params = params*noise.paramGroups';
startVal = 1;
endVal = 0;
for i = 1:length(noise.comp)
  endVal = endVal + noise.comp{i}.nParams;
  noise.comp{i} = noiseExpandParam(noise.comp{i}, params(1, startVal:endVal));
  startVal = endVal + 1;
end
