function L = ngaussLikelihood(noise, mu, varsigma, y)

% NGAUSSLIKELIHOOD Likelihood of data under noiseless Gaussian noise model.
%
% L = ngaussLikelihood(noise, mu, varsigma, y)
%

% Copyright (c) 2005 Neil D. Lawrence
% ngaussLikelihood.m version 1.2





L = gaussianLikelihood(noise, mu, varsigma, y);