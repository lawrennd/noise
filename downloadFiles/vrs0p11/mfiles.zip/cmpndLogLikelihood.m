function L = cmpndLogLikelihood(noise, mu, varsigma, y)

% CMPNDLOGLIKELIHOOD Log-likelihood of data under compound noise model.
%
% L = cmpndLogLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11





L = 0;
for i = 1:length(noise.comp)
  L = L + noiseLogLikelihood(noise.comp{i}, ...
			     mu(:, i), ...
			     varsigma(:, i), ...
			     y(:, i));
end