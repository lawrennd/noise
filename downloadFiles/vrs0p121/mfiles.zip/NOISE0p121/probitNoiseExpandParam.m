function noise = probitNoiseExpandParam(noise, params)

% PROBITNOISEEXPANDPARAM Expand probit noise structure from param vector.
%
% noise = probitNoiseExpandParam(noise, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Mon Jul 26 08:32:53 2004
% NOISE toolbox version 0.121



noise.bias = params(1:end);

