function orderedNoisePointPlot(noise, X, y, ...
                              fontName, fontSize, ...
                              markerSize, lineWidth);

% ORDEREDNOISEPOINTPLOT Plot the data-points for ordered categorical noise model.
%
% orderedNoisePointPlot(noise, X, y, ...
%                               fontName, fontSize, ...
%                               markerSize, lineWidth);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Fri Jun 18 20:03:07 2004
% NOISE toolbox version 0.12



symbol = getSymbols(noise.C);
for i = 1:noise.C
  plot(X(find(y==i-1), 1), X(find(y==i-1), 2), symbol{i}, 'erasemode', ...
       'xor', 'markerSize', markerSize, 'linewidth', lineWidth);
  hold on
end

minVals = min([X]);
maxVals = max([X]);

spans = maxVals - minVals;
gaps = spans*.05;

prop = {'xlim', 'ylim'};
for i = 1:2
  set(gca, prop{i}, [minVals(i)-gaps(i) maxVals(i)+gaps(i)]);
end
hold on