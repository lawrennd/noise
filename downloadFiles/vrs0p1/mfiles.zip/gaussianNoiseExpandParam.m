function noise = gaussianNoiseExpandParam(noise, params)

% GAUSSIANNOISEEXPANDPARAM Expand Gaussian noise structure from param vector.
%
% noise = gaussianNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1





noise.bias = params(1:end-1);
noise.sigma2 = params(end);