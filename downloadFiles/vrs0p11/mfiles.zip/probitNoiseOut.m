function y = probitNoiseOut(noise, mu, varsigma)

% PROBITNOISEOUT Output from probit noise model.
%
% y = probitNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 14 10:28:20 2004
% NOISE toolbox version 0.11



D = size(mu, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
y = sign(mu);
