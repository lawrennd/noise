function L = probitLogLikelihood(noise, mu, varsigma, y)

% PROBITLOGLIKELIHOOD Log-likelihood of data under probit noise model.
%
%	Description:
%	L = probitLogLikelihood(noise, mu, varsigma, y)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	probitLogLikelihood.m version 1.3


D = size(y, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end

L = sum(sum(lnCumGaussian((y.*mu)./(sqrt(noise.sigma2+varsigma)))));
