function y = probitNoiseOut(noise, mu, varsigma)

% PROBITNOISEOUT Output from probit noise model.
%
%	Description:
%	y = probitNoiseOut(noise, mu, varsigma)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	probitNoiseOut.m version 1.3


D = size(mu, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
y = sign(mu);
