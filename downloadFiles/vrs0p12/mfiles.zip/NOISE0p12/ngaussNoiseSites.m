function [m, beta] = ngaussNoiseSites(noise, g, nu, mu, varSigma, y)

% NGAUSSNOISESITES Site updates for noiseless Gaussian noise model.
%
% [m, beta] = ngaussNoiseSites(noise, g, nu, mu, varSigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





[m, beta] = gaussianNoiseSites(noise, g, nu, mu, varSigma, y);