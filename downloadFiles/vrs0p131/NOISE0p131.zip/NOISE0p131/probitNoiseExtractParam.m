function [params, names] = probitNoiseExtractParam(noise)

% PROBITNOISEEXTRACTPARAM Extract parameters from probit noise model.
%
%	Description:
%	[params, names] = probitNoiseExtractParam(noise)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	probitNoiseExtractParam.m version 1.3


params = [noise.bias];

if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
end