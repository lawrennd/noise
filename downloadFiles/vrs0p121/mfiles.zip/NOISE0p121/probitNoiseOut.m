function y = probitNoiseOut(noise, mu, varsigma)

% PROBITNOISEOUT Output from probit noise model.
%
% y = probitNoiseOut(noise, mu, varsigma)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Apr 23 15:24:22 2005
% NOISE toolbox version 0.121



D = size(mu, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
y = sign(mu);
