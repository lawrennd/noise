function [dlnZ_dmu, dlnZ_dvs] = noiseGradVals(noise, mu, varsigma, y)

% NOISEGRADVALS Gradient of noise model wrt mu and varsigma.
%
% [dlnZ_dmu, dlnZ_dvs] = noiseGradVals(noise, mu, varsigma, y)
%

% Copyright (c) 2005 Neil D. Lawrence
% noiseGradVals.m version 1.4


fhandle = str2func([noise.type 'NoiseGradVals']);
[dlnZ_dmu, dlnZ_dvs] = fhandle(noise, mu, ...
                               varsigma, y);
