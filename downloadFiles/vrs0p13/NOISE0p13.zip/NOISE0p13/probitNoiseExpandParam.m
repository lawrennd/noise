function noise = probitNoiseExpandParam(noise, params)

% PROBITNOISEEXPANDPARAM Expand probit noise structure from param vector.
%
% noise = probitNoiseExpandParam(noise, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% probitNoiseExpandParam.m version 1.3



noise.bias = params(1:end);

