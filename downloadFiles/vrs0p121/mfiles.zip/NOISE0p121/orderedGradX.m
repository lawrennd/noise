function g = orderedGradX(X, Y, model, prior)

% ORDEREDGRADX Gradient wrt x of log-likelihood for Ordered categorical model.
%
% g = orderedGradX(X, Y, model, prior)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.121





if size(X, 1) > 1
  error('This function only takes one data-point');
end