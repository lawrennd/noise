function gaussianNoisePointPlot(noise, X, y, ...
                              fontName, fontSize, ...
                              markerSize, lineWidth);

% GAUSSIANNOISEPOINTPLOT Plot the data-points for ordered categorical noise model.
%
% gaussianNoisePointPlot(noise, X, y, ...
%                               fontName, fontSize, ...
%                               markerSize, lineWidth);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 16 10:58:31 2004
% NOISE toolbox version 0.11



plot3(X(:, 1), X(:, 2), y, 'r.', 'erasemode', 'xor',  'markerSize', markerSize, 'linewidth', lineWidth);

minVals = min([X y]);
maxVals = max([X y]);

spans = maxVals - minVals;
gaps = spans*.05;

prop = {'xlim', 'ylim', 'zlim'};
for i = 1:3
  set(gca, prop{i}, [minVals(i)-gaps(i) maxVals(i)+gaps(i)]);
end
hold on