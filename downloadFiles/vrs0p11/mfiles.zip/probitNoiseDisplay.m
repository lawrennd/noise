function probitNoiseDisplay(noise)

% PROBITNOISEDISPLAY Display the parameters of the Probit noise model.
%
% probitNoiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11





for i = 1:noise.numProcess
  fprintf('Probit bias on process %d: %2.4f\n', i, noise.bias(i))
end
fprintf('Probit Sigma2: %2.4f\n', noise.sigma2)
