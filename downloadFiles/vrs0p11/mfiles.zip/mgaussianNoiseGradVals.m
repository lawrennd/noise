function [dlnZ_dmu, dlnZ_dvs] = mgaussianNoiseGradVals(noise, mu, varsigma, y)

% MGAUSSIANNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for Variable variance Gaussian noise model.
%
% [dlnZ_dmu, dlnZ_dvs] = mgaussianNoiseGradVals(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11





D = size(y, 2);
nu = zeros(size(y));
dlnZ_dmu = zeros(size(y));
for i = 1:D
  nu(:, i) = 1./(noise.sigma2(i)+varsigma(:, i));
  dlnZ_dmu(:, i) = y(:, i) - mu(:, i) - noise.bias(i);
end
dlnZ_dmu = dlnZ_dmu.*nu;
dlnZ_dvs = -.5*nu+.5*dlnZ_dmu.*dlnZ_dmu;

% Remove missing values.
dlnZ_dmu(find(isnan(y))) = 0;
dlnZ_dvs(find(isnan(y))) = 0;
