function ngaussNoiseDisplay(noise)

% NGAUSSNOISEDISPLAY Display  parameters from noiseless Gaussian noise model.
%
% ngaussNoiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12






for i = 1:noise.numProcess
  fprintf('Noiseless Gaussian bias on process %d: %2.4f\n', i, noise.bias(i))
end
