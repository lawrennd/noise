function y = scaleNoiseOut(noise, mu, varSigma)

% SCALENOISEOUT A simple noise model that scales and centres the data.
%
% y = scaleNoiseOut(noise, mu, varSigma)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:17:53 2005
% NOISE toolbox version 0.121



y = zeros(size(mu));
for i = 1:size(mu, 2)
  y(:, i) = noise.bias(i) + mu(:, i)*noise.scale(i);
end


