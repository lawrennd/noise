function noise = cmpndNoiseParamInit(noise, y)

% CMPNDNOISEPARAMINIT Compound noise model's parameter initialisation.
%
% noise = cmpndNoiseParamInit(noise, y)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Apr  6 18:56:41 2005
% NOISE toolbox version 0.121



if nargin > 1
  if length(noise.comp) ~= size(y, 2)
    error('Number of noise components must match y''s  dimensions')
  end
end
noise.nParams = 0;
for i = 1:length(noise.comp)
  if nargin > 1
    noise.comp{i} = noiseParamInit(noise.comp{i}, y(:, i));
  else
    noise.comp{i}.numProcess=1;
    noise.comp{i} = noiseParamInit(noise.comp{i});
  end    
  noise.nParams = noise.nParams + noise.comp{i}.nParams;
end
noise.paramGroups = speye(noise.nParams);
% This is a bit of a hack.
noise.missing=0;
