function g = probitNoiseGradientParam(noise, mu, varsigma, y)

% PROBITNOISEGRADIENTPARAM Gradient of the probit noise model's parameters.
%
% g = probitNoiseGradientParam(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





c = y./sqrt(noise.sigma2 + varsigma);
for i = 1:size(mu, 2)
  u(:, i) = c(:, i).*(mu(:, i) + noise.bias(i));
end
g = sum(c.*gradLogCumGaussian(u), 1);