function y = ngaussNoiseOut(noise, mu, varsigma)

% NGAUSSNOISEOUT Ouput from noiseless Gaussian noise model.
%
% y = ngaussNoiseOut(noise, mu, varsigma)
%

% Copyright (c) 2005 Neil D. Lawrence
% ngaussNoiseOut.m version 1.3



y = gaussianNoiseOut(noise, mu, varsigma);