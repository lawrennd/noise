function L = ngaussLogLikelihood(noise, mu, varsigma, y)

% NGAUSSLOGLIKELIHOOD Log-likelihood of data under noiseless Gaussian noise model.
%
%	Description:
%	L = ngaussLogLikelihood(noise, mu, varsigma, y)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	ngaussLogLikelihood.m version 1.2




L = gaussianLogLikelihood(noise, mu, varsigma, y);
