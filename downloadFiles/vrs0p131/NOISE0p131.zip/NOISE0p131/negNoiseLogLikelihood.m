function e = negNoiseLogLikelihood(params, model, prior)

% NEGNOISELOGLIKELIHOOD Wrapper function for calling noise likelihoods.
%
%	Description:
%	e = negNoiseLogLikelihood(params, model, prior)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	negNoiseLogLikelihood.m version 1.3


model.noise = noiseExpandParam(model.noise, params);
fhandle = str2func([model.noise.type 'LogLikelihood']);
e = - fhandle([], [], model);

if prior
  e =e +0.5*params*params';
end