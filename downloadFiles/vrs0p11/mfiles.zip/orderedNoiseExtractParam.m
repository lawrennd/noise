function [params, names] = orderedNoiseExtractParam(noise)

% ORDEREDNOISEEXTRACTPARAM Extract parameters from ordered categorical noise model.
%
% [params, names] = orderedNoiseExtractParam(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11




params = [noise.bias noise.widths(:)'];
if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
  for i = 1:noise.C-2
    names{noise.numProcess+i} = ['width ' num2str(i)];
  end
end