function y = gaussianNoiseOut(noise, mu, varsigma)

% GAUSSIANNOISEOUT Output from Gaussian noise model.
%
%	Description:
%	y = gaussianNoiseOut(noise, mu, varsigma)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	gaussianNoiseOut.m version 1.3


D = size(mu, 2);
y = zeros(size(mu));
for i = 1:D
  y(:, i) = mu(:, i) + noise.bias(i);
end
