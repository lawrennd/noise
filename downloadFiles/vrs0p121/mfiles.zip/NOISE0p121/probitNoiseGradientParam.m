function g = probitNoiseGradientParam(noise, mu, varsigma, y)

% PROBITNOISEGRADIENTPARAM Gradient of the probit noise model's parameters.
%
% g = probitNoiseGradientParam(noise, mu, varsigma, y)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sat Apr 23 14:53:22 2005
% NOISE toolbox version 0.121



c = y./sqrt(noise.sigma2 + varsigma);
for i = 1:size(mu, 2)
  u(:, i) = c(:, i).*(mu(:, i) + noise.bias(i));
end
g = sum(c.*gradLogCumGaussian(u), 1);