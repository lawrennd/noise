function gaussianNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% GAUSSIANNOISE3DPLOT Draw a 3D or contour plot for the Gassian noise model.
%
% gaussianNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 16 09:10:56 2004
% NOISE toolbox version 0.11



CZ = (CZ+noise.bias);
feval(plotType, CX, CY, CZ, varargin{:});
