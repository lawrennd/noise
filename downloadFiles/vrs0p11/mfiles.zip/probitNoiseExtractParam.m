function [params, names] = probitNoiseExtractParam(noise)

% PROBITNOISEEXTRACTPARAM Extract parameters from probit noise model.
%
% [params, names] = probitNoiseExtractParam(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11





params = [noise.bias];

if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
end