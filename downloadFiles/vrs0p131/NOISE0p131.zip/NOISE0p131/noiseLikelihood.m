function L = noiseLikelihood(noise, mu, varsigma, y);

% NOISELIKELIHOOD Return the likelihood for each point under the noise model.
%
%	Description:
%	L = noiseLikelihood(noise, mu, varsigma, y);
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	noiseLikelihood.m version 1.4


fhandle = str2func([noise.type 'Likelihood']);
L = fhandle(noise, mu, varsigma, y);
