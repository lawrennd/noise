function y = ngaussNoiseOut(noise, mu, varsigma)

% NGAUSSNOISEOUT Ouput from noiseless Gaussian noise model.
%
%	Description:
%	y = ngaussNoiseOut(noise, mu, varsigma)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	ngaussNoiseOut.m version 1.3


y = gaussianNoiseOut(noise, mu, varsigma);