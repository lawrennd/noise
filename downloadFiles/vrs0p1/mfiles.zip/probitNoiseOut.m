function y = probitNoiseOut(noise, mu, varsigma)

% PROBITNOISEOUT Output from probit noise model.
%
% y = probitNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1




D = size(mu, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
y = sign(mu);
