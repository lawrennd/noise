function [g, nu] = ngaussNoiseNuG(noise, mu, varSigma, y)

% NGAUSSNOISENUG Update nu and g parameters associated with noiseless Gaussian noise model.
%
% [g, nu] = ngaussNoiseNuG(noise, mu, varSigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





[g, nu] = gaussianNoiseNuG(noise, mu, varSigma, y);
