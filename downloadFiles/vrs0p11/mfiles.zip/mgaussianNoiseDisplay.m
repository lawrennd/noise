function mgaussianNoiseDisplay(noise)

% MGAUSSIANNOISEDISPLAY Display  parameters from Variable variance Gaussian noise model.
%
% mgaussianNoiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11






for i = 1:noise.numProcess
  fprintf('MGaussian bias on process %d: %2.4f\n', i, noise.bias(i))
  fprintf('MGaussian variance on process %d: %2.4f\n', i, noise.sigma2(i))
end

