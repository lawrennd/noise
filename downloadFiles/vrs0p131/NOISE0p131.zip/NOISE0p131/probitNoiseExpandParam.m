function noise = probitNoiseExpandParam(noise, params)

% PROBITNOISEEXPANDPARAM Expand probit noise structure from param vector.
%
%	Description:
%	noise = probitNoiseExpandParam(noise, params)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	probitNoiseExpandParam.m version 1.3


noise.bias = params(1:end);

