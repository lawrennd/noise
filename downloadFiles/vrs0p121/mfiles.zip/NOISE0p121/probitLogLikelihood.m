function L = probitLogLikelihood(noise, mu, varsigma, y)

% PROBITLOGLIKELIHOOD Log-likelihood of data under probit noise model.
%
% L = probitLogLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Mon Jul 26 08:35:56 2004
% NOISE toolbox version 0.121



D = size(y, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end

L = sum(sum(lnCumGaussian((y.*mu)./(sqrt(noise.sigma2+varsigma)))));
