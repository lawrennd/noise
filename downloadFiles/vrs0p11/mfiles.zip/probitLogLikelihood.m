function L = probitLogLikelihood(noise, mu, varsigma, y)

% PROBITLOGLIKELIHOOD Log-likelihood of data under probit noise model.
%
% L = probitLogLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11





D = size(y, 2);
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
end
L = sum(sum(lnCumGaussian((y.*mu)./(sqrt(noise.sigma2+varsigma)))));
