function [dlnZ_dmu, dlnZ_dvs] = noiseGradVals(noise, mu, varsigma, y)

% NOISEGRADVALS Gradient of noise model wrt mu and varsigma.
%
% [dlnZ_dmu, dlnZ_dvs] = noiseGradVals(noise, mu, varsigma, y)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Tue Feb 22 15:46:23 2005
% NOISE toolbox version 0.121



[dlnZ_dmu, dlnZ_dvs] = feval([noise.type 'NoiseGradVals'], noise, mu, ...
                             varsigma, y);
