function [dlnZ_dmu, dlnZ_dvs] = cmpndNoiseGradVals(noise, mu, varsigma, y)

% CMPNDNOISEGRADVALS Gradient wrt x of log-likelihood for compound noise model.
%
% [dlnZ_dmu, dlnZ_dvs] = cmpndNoiseGradVals(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11





startVal = 1;
endVal = 0;
dlnZ_dmu = zeros(size(mu));
dlnZ_dvs = zeros(size(varsigma));
for i = 1:length(noise.comp)
  [dlnZ_dmu(:, i), dlnZ_dvs(:, i)]  = feval([noise.comp{i}.type 'NoiseGradVals'], ...
                                 noise.comp{i}, ...
                                 mu(:, i), ...
                                 varsigma(:, i), ...
                                 y(:, i));
end
