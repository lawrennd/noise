function y = ngaussNoiseOut(noise, mu, varsigma)

% NGAUSSNOISEOUT Ouput from noiseless Gaussian noise model.
%
% y = ngaussNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1





y = gaussianNoiseOut(noise, mu, varsigma);