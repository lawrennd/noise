function h = noisePointPlot(noise, X, y,  ...
                        fontName, fontSize, ...
                        markerSize, lineWidth)

% NOISEPOINTPLOT
%
%	Description:
%	h = noisePointPlot(noise, X, y,  ...
%                        fontName, fontSize, ...
%                        markerSize, lineWidth)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	noisePointPlot.m version 1.4


fhandle = str2func([noise.type 'NoisePointPlot']);
h = fhandle(noise, X, y, ...
      fontName, fontSize, ...
      markerSize, lineWidth);

set(gca, 'fontname', fontName, 'fontsize', fontSize);