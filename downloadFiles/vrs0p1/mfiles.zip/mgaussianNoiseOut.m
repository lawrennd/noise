function y = mgaussianNoiseOut(noise, mu, varsigma)

% MGAUSSIANNOISEOUT Ouput from Variable variance Gaussian noise model.
%
% y = mgaussianNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1





D = size(mu, 2);
y = zeros(size(mu));
for i = 1:D
  y(:, i) = mu(:, i) + noise.bias(i);
end

