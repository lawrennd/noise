function e = negNoiseLogLikelihood(params, model, prior)

% NEGNOISELOGLIKELIHOOD Wrapper function for calling noise likelihoods.
%
% e = negNoiseLogLikelihood(params, model, prior)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.121





model.noise = noiseExpandParam(model.noise, params);
e = - feval([model.noise.type 'LogLikelihood'], [], [], model);

if prior
  e =e +0.5*params*params';
end