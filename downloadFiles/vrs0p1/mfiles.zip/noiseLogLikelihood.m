function L = noiseLogLikelihood(noise, mu, varsigma, y);

% NOISELOGLIKELIHOOD Return the log-likelihood under the noise model.
%
% L = noiseLogLikelihood(noise, mu, varsigma, y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1





L = feval([noise.type 'LogLikelihood'], noise, mu, varsigma, y);


% check if there is a prior over parameters
if isfield(noise, 'priors')
  params = feval([noise.type 'NoiseExpandParams'], noise);
  for i = 1:length(noise.priors)
    index = noise.priors(i).index;
    L = L + priorLogProb(noise.priors(i), params(index));
  end
end
