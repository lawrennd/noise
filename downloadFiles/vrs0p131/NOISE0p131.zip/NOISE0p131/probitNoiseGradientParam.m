function g = probitNoiseGradientParam(noise, mu, varsigma, y)

% PROBITNOISEGRADIENTPARAM Gradient of the probit noise model's parameters.
%
%	Description:
%	g = probitNoiseGradientParam(noise, mu, varsigma, y)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	probitNoiseGradientParam.m version 1.3


c = y./sqrt(noise.sigma2 + varsigma);
for i = 1:size(mu, 2)
  u(:, i) = c(:, i).*(mu(:, i) + noise.bias(i));
end
g = sum(c.*gradLogCumGaussian(u), 1);