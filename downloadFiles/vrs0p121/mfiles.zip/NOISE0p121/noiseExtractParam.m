function [params, names] = noiseExtractParam(noise)

% NOISEEXTRACTPARAM Extract the noise model's parameters.
%
% [params, names] = noiseExtractParam(noise)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Tue Mar  8 11:25:32 2005
% NOISE toolbox version 0.121



if nargout < 2
  params = feval([noise.type 'NoiseExtractParam'], noise);
else
  [params, names] = feval([noise.type 'NoiseExtractParam'], noise);
end


% Check if parameters are being optimised in a transformed space.
if isfield(noise, 'transforms')
  for i = 1:length(noise.transforms)
    index = noise.transforms(i).index;
    params(index) = feval([noise.transforms(i).type 'Transform'], ...
              params(index), 'xtoa');
  end
end