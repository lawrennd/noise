function L = cmpndLikelihood(noise, mu, varsigma, y)

% CMPNDLIKELIHOOD Likelihood of data under compound noise model.
%
% L = cmpndLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





L = zeros(size(mu));
for i = 1:length(noise.comp)
  L(:, i) = noiseLikelihood(noise.comp{i},...
                mu(:, i), ...
                varsigma(:, i), ...
                y(:, i));
end