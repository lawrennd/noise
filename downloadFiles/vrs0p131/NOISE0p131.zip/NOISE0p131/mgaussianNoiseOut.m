function y = mgaussianNoiseOut(noise, mu, varsigma)

% MGAUSSIANNOISEOUT Ouput from Variable variance Gaussian noise model.
%
%	Description:
%	y = mgaussianNoiseOut(noise, mu, varsigma)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	mgaussianNoiseOut.m version 1.3


D = size(mu, 2);
y = zeros(size(mu));
for i = 1:D
  y(:, i) = mu(:, i) + noise.bias(i);
end

