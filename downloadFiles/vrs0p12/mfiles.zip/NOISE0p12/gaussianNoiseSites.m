function [m, beta] = gaussianNoiseSites(noise, g, nu, mu, varSigma, y)

% GAUSSIANNOISESITES Site updates for Gaussian noise model.
%
% [m, beta] = gaussianNoiseSites(noise, g, nu, mu, varSigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 21 09:27:19 2004
% NOISE toolbox version 0.12



N = size(y, 1);
D = length(noise.bias);
beta = zeros(N, D);
for i = 1:size(y, 2)
  m(:, i) = y(:, i) - noise.bias(i);
end
beta = repmat(1./noise.sigma2, N, D);