function noise = cmpndNoiseParamInit(noise, y)

% CMPNDNOISEPARAMINIT Compound noise model's parameter initialisation.
%
% noise = cmpndNoiseParamInit(noise, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





if nargin > 1
  if length(noise.comp) ~= size(y, 2)
    error('Number of noise components must match y''s  dimensions')
  end
end
noise.nParams = 0;
for i = 1:length(noise.comp)
  if nargin > 1
    noise.comp{i} = noiseParamInit(noise.comp{i}, y(:, i));
  else
    noise.comp{i} = noiseParamInit(noise.comp{i});
  end    
  noise.nParams = noise.nParams + noise.comp{i}.nParams;
end
noise.paramGroups = speye(noise.nParams);

