function noise = mgaussianNoiseExpandParam(noise, params)

% MGAUSSIANNOISEEXPANDPARAM Expand Variable variance Gaussian noise model's structure from param vector.
%
% noise = mgaussianNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1





noise.bias = params(1:noise.numProcess);
noise.sigma2 = params(noise.numProcess+1:end);