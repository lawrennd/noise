function orderedNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% ORDEREDNOISE3DPLOT Draw a 3D or contour plot for the probit.
%
% orderedNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 16 09:11:04 2004
% NOISE toolbox version 0.11



CZ = (CZ+noise.bias)./sqrt(CZVar);
feval(plotType, CX, CY, CZ, varargin{:});
hold on
for i = 2:noise.C-1
  CZ = CZ - noise.widths(i-1)./sqrt(CZVar);
  feval(plotType, CX, CY, CZ, varargin{:});
end
