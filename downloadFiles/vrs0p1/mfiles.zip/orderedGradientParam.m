function g = orderedGradientParam(model, params)

% ORDEREDGRADIENTPARAM Gradient of the Ordered categorical model's parameters.
%
% g = orderedGradientParam(model, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1





