% NOISE toolbox
% Version 0.131		Saturday 14 Oct 2006 at 22:04
% Copyright (c) 2006 Neil D. Lawrence
% 
% CMPNDLIKELIHOOD Likelihood of data under compound noise model.
% CMPNDLOGLIKELIHOOD Log-likelihood of data under compound noise model.
% CMPNDNOISEDISPLAY Display the parameters of the compound noise model.
% CMPNDNOISEEXPANDPARAM Expand probit noise structure from param vector.
% CMPNDNOISEEXTRACTPARAM Extract parameters from compound noise model.
% CMPNDNOISEGRADVALS Gradient wrt x of log-likelihood for compound noise model.
% CMPNDNOISEGRADIENTPARAM Gradient of the compound noise model's parameters.
% CMPNDNOISENUG  Update nu and g parameters associated with compound noise model.
% CMPNDNOISEOUT Output from compound noise model.
% CMPNDNOISEPARAMINIT Compound noise model's parameter initialisation.
% CMPNDNOISESITES Site updates for compound noise model.
% GAUSSIANLIKELIHOOD Likelihood of data under Gaussian noise model.
% GAUSSIANLOGLIKELIHOOD Log-likelihood of data under Gaussian noise model.
% GAUSSIANNOISE3DPLOT Draw a 3D or contour plot for the Gassian noise model.
% GAUSSIANNOISEDISPLAY Display the parameters of the Gaussian noise model.
% GAUSSIANNOISENUG Update nu and g parameters associated with Gaussian noise model.
% GAUSSIANNOISEEXPANDPARAM Expand Gaussian noise structure from param vector.
% GAUSSIANNOISEEXTRACTPARAM Extract parameters from Gaussian noise model.
% GAUSSIANNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for gaussian noise model.
% GAUSSIANNOISEGRADIENTPARAM Gradient of the Gaussian noise model's parameters.
% GAUSSIANNOISEOUT Output from Gaussian noise model.
% GAUSSIANNOISEPARAMINIT Gaussian noise model's parameter initialisation.
% GAUSSIANNOISEPOINTPLOT Plot the data-points for ordered categorical noise model.
% GAUSSIANNOISESITES Site updates for Gaussian noise model.
% MGAUSSIANLIKELIHOOD Likelihood of data under Variable variance Gaussian noise model.
% MGAUSSIANLOGLIKELIHOOD Log-likelihood of data under Variable variance Gaussian noise model.
% MGAUSSIANNOISEDISPLAY Display  parameters from Variable variance Gaussian noise model.
% MGAUSSIANNOISEEXPANDPARAM Expand Variable variance Gaussian noise model's structure from param vector.
% MGAUSSIANNOISEEXTRACTPARAM Extract parameters from Variable variance Gaussian noise model.
% MGAUSSIANNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for Variable variance Gaussian noise model.
% MGAUSSIANNOISEGRADIENTPARAM Gradient of the Variable variance Gaussian noise model's parameters.
% MGAUSSIANNOISEOUT Ouput from Variable variance Gaussian noise model.
% MGAUSSIANNOISEPARAMINIT Variable variance Gaussian noise model's parameter initialisation.
% NEGNOISEGRADIENTPARAM Wrapper function for calling noise gradients.
% NEGNOISELOGLIKELIHOOD Wrapper function for calling noise likelihoods.
% NGAUSSLIKELIHOOD Likelihood of data under noiseless Gaussian noise model.
% NGAUSSLOGLIKELIHOOD Log-likelihood of data under noiseless Gaussian noise model.
% NGAUSSNOISEDISPLAY Display  parameters from noiseless Gaussian noise model.
% NGAUSSNOISEEXPANDPARAM Expand noiseless Gaussian noise model's structure from param vector.
% NGAUSSNOISEEXTRACTPARAM Extract parameters from noiseless Gaussian noise model.
% NGAUSSNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for noiseless Gaussian noise model.
% NGAUSSNOISEGRADIENTPARAM Gradient of the noiseless Gaussian noise model's parameters.
% NGAUSSNOISENUG Update nu and g parameters associated with noiseless Gaussian noise model.
% NGAUSSNOISEOUT Ouput from noiseless Gaussian noise model.
% NGAUSSNOISEPARAMINIT noiseless Gaussian noise model's parameter initialisation.
% NGAUSSNOISESITES Site updates for noiseless Gaussian noise model.
% NOISE3DPLOT Draw a 3D or contour plot for the relevant noise model.
% NOISECREATE Initialise a noise structure.
% NOISEDISPLAY Display the parameters of the noise model.
% NOISEEXPANDPARAM Expand the noise model's parameters from params vector.
% NOISEEXTRACTPARAM Extract the noise model's parameters.
% NOISEGRADVALS Gradient of noise model wrt mu and varsigma.
% NOISEGRADX Returns the gradient of the log-likelihood wrt x.
% NOISEGRADIENTPARAM Gradient of the noise model's parameters.
% NOISELIKELIHOOD Return the likelihood for each point under the noise model.
% NOISELOGLIKELIHOOD Return the log-likelihood under the noise model.
% NOISEOUT Give the output of the noise model given the mean and variance.
% NOISEPARAMINIT Noise model's parameter initialisation.
% NOISEPOINTPLOT 
% NOISEREADFROMFID Load from an FID written by the C++ implementation.
% NOISEREADPARAMSFROMFID Read the noise parameters from C++ file FID.
% NOISETEST Run some tests on the specified noise model.
% NOISEUPDATENUG Update nu and g for a given noise model.
% NOISEUPDATESITES Update site parameters for a given noise model.
% ORDEREDGRADX Gradient wrt x of log-likelihood for Ordered categorical model.
% ORDEREDLIKELIHOOD Likelihood of data under ordered categorical noise model.
% ORDEREDLOGLIKELIHOOD Log-likelihood of data under ordered categorical noise model.
% ORDEREDNOISE3DPLOT Draw a 3D or contour plot for the probit.
% ORDEREDNOISEDISPLAY Display the parameters of the ordered categorical noise model.
% ORDEREDNOISEEXPANDPARAM Expand ordered categorical noise model's structure from param vector.
% ORDEREDNOISEEXTRACTPARAM Extract parameters from ordered categorical noise model.
% ORDEREDNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for ordered categorical noise model.
% ORDEREDNOISEGRADIENTPARAM Gradient of the ordered categorical noise model's parameters.
% ORDEREDNOISEOUT Output from ordered categorical noise model.
% ORDEREDNOISEPARAMINIT Ordered categorical noise model's parameter initialisation.
% ORDEREDNOISEPOINTPLOT Plot the data-points for ordered categorical noise model.
% ORDEREDNOISEUPDATEPARAMS Update parameters for ordered categorical noise model.
% PROBIT3DPLOT Draw a 3D or contour plot for the probit.
% PROBITLIKELIHOOD Likelihood of data under probit noise model.
% PROBITLOGLIKELIHOOD Log-likelihood of data under probit noise model.
% PROBITNOISE3DPLOT Draw a 3D or contour plot for the probit.
% PROBITNOISEDISPLAY Display the parameters of the Probit noise model.
% PROBITNOISEEXPANDPARAM Expand probit noise structure from param vector.
% PROBITNOISEEXTRACTPARAM Extract parameters from probit noise model.
% PROBITNOISEGRADVALS Gradient wrt mu and varsigma of log-likelihood for probit noise model.
% PROBITNOISEGRADIENTPARAM Gradient of the probit noise model's parameters.
% PROBITNOISEOUT Output from probit noise model.
% PROBITNOISEPARAMINIT probistic classification model's parameter initialisation.
% PROBITNOISEPOINTPLOT Plot the data-points for probit noise model.
% SCALENOISEEXPANDPARAM Expand Scale noise structure from param vector.
% SCALENOISEOUT A simple noise model that scales and centres the data.
% SCALENOISEPARAMINIT Scale noise model's parameter initialisation.
% SCALENOISESITES Site updates for Scale noise model.
% SCALENOISEDISPLAY Display the parameters of the scaled noise model.
