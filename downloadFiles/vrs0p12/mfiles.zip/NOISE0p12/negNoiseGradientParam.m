function g = negNoiseGradientParam(params, model, prior)

% NEGNOISEGRADIENTPARAM Wrapper function for calling noise gradients.
%
% g = negNoiseGradientParam(params, model, prior)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





model.noise = noiseExpandParam(model.noise, params);
g = - feval([model.noise.type 'GradientParam'], model);

if prior
  g =g +params;
end