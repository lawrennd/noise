function y = noiseOut(noise, mu, varsigma);

% NOISEOUT Give the output of the noise model given the mean and variance.
%
% y = noiseOut(noise, mu, varsigma);

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Sun Feb 27 19:34:23 2005
% NOISE toolbox version 0.121



fhandle = str2func([noise.type 'NoiseOut']);
if str2num(version('-release'))>13
  y = fhandle(noise, mu, varsigma);
else
  y = feval(fhandle, noise, mu, varsigma);
end