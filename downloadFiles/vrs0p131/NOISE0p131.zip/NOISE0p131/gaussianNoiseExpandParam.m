function noise = gaussianNoiseExpandParam(noise, params)

% GAUSSIANNOISEEXPANDPARAM Expand Gaussian noise structure from param vector.
%
%	Description:
%	noise = gaussianNoiseExpandParam(noise, params)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	gaussianNoiseExpandParam.m version 1.3


noise.bias = params(1:end-1);
noise.sigma2 = params(end);