function gaussianNoiseDisplay(noise)

% GAUSSIANNOISEDISPLAY Display the parameters of the Gaussian noise model.
%
% gaussianNoiseDisplay(noise)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.4, Thu May  5 16:01:55 2005
% NOISE toolbox version 0.121



for i = 1:noise.numProcess
  fprintf('Gaussian bias on process %d: %2.4f\n', i, noise.bias(i))
end
fprintf('Gaussian noise: %2.4f\n', noise.sigma2);