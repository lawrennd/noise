function noise = ngaussNoiseExpandParam(noise, params)

% NGAUSSNOISEEXPANDPARAM Expand noiseless Gaussian noise model's structure from param vector.
%
%	Description:
%	noise = ngaussNoiseExpandParam(noise, params)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	ngaussNoiseExpandParam.m version 1.2




noise.bias = params(1:end);