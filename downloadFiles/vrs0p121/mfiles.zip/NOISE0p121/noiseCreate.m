function noise = noiseCreate(noiseType, y)

% NOISECREATE Initialise a noise structure.
%
% noise = noiseCreate(noiseType, y)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Apr  6 18:56:41 2005
% NOISE toolbox version 0.121



if isstruct(noiseType)
  noise = noiseType;
  return
elseif iscell(noiseType)
  % compound noise type
  noise.type = 'cmpnd';
  if nargin > 1
    for i = 1:length(noiseType)
      noise.comp{i} = noiseCreate(noiseType{i}, y(:, i));
    end
  else
    for i = 1:length(noiseType)
      noise.comp{i} = noiseCreate(noiseType{i});
    end
  end
else
  noise.type = noiseType;
end

if nargin>1
  noise = noiseParamInit(noise, y);
end

% Check if the noise model has bespoke site update code
if exist([noise.type 'NoiseSites'])==2
  noise.updateSites = 1;
else
  noise.updateSites = 0;
end

% Check if the model has bespoke nu and g update code.
if exist([noise.type 'NoiseNuG'])==2
  noise.updateNuG = 1;
else
  noise.updateNuG = 0;
end