function g = mgaussianNoiseGradientParam(noise, mu, varsigma, y)

% MGAUSSIANNOISEGRADIENTPARAM Gradient of the Variable variance Gaussian noise model's parameters.
%
% g = mgaussianNoiseGradientParam(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11






D = size(y, 2);
u = zeros(size(y));
nu = zeros(size(y));
for i = 1:D
  mu(:, i) = mu(:, i) + noise.bias(i);
  nu(:, i) = 1./(varsigma(:, i) + noise.sigma2(i));
end

u = y - mu;

% Remove unlabelled points from the gradient.
u(find(isnan(y))) = 0;
nu(find(isnan(y)))= 0;
u = u.*nu;
gbias = sum(u, 1);
gsigma2 = -.5*sum(nu - u.*u, 1);
g = [gbias gsigma2];
