function h = gaussianNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% GAUSSIANNOISE3DPLOT Draw a 3D or contour plot for the Gassian noise model.
%
% h = gaussianNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Thu Jan 20 02:13:19 2005
% NOISE toolbox version 0.121



CZ = (CZ+noise.bias);
h = feval(plotType, CX, CY, CZ, varargin{:});
