function y = cmpndNoiseOut(noise, mu, varsigma)

% CMPNDNOISEOUT Output from compound noise model.
%
% y = cmpndNoiseOut(noise, mu, varsigma)
%

% Copyright (c) 2005 Neil D. Lawrence
% cmpndNoiseOut.m version 1.3



y = zeros(size(mu));
for i = 1:length(noise.comp)
  fhandle = str2func([noise.comp{i}.type 'NoiseOut']);
  y(:, i) = fhandle(noise.comp{i},...
                    mu(:, i), ...
                    varsigma(:, i));
end

