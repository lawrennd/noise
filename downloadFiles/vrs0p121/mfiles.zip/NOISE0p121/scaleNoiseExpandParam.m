function noise = scaleNoiseExpandParam(noise, params)

% SCALENOISEEXPANDPARAM Expand Scale noise structure from param vector.
%
% noise = scaleNoiseExpandParam(noise, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.1, Sat Jul 23 05:17:53 2005
% NOISE toolbox version 0.121



noise.bias = params(1:noise.numProcess);
noise.scale = params(noise.numProcess+1:end);