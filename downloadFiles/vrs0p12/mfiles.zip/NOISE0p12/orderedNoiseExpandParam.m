function noise = orderedNoiseExpandParam(noise, params)

% ORDEREDNOISEEXPANDPARAM Expand ordered categorical noise model's structure from param vector.
%
% noise = orderedNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





noise.bias = params(1:noise.numProcess);
noise.widths = params(noise.numProcess+1:end)';
