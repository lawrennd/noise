function y = noiseOut(noise, mu, varsigma);

% NOISEOUT Give the output of the noise model given the mean and variance.
%
% y = noiseOut(noise, mu, varsigma);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





y = feval([noise.type 'NoiseOut'], noise, mu, varsigma);