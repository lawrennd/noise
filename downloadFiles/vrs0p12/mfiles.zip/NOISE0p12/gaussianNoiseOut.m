function y = gaussianNoiseOut(noise, mu, varsigma)

% GAUSSIANNOISEOUT Output from Gaussian noise model.
%
% y = gaussianNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





D = size(mu, 2);
y = zeros(size(mu));
for i = 1:D
  y(:, i) = mu(:, i) + noise.bias(i);
end
