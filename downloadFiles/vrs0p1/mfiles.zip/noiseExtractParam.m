function [params, names] = noiseExtractParam(noise)

% NOISEEXTRACTPARAM Extract the noise model's parameters.
%
% [params, names] = noiseExtractParam(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.1





if nargout < 2
  params = feval([noise.type 'NoiseExtractParam'], noise);
else
  [params, names] = feval([noise.type 'NoiseExtractParam'], noise);
end


% Check if parameters are being optimised in a transformed space.
if isfield(noise, 'transforms')
  for i = 1:length(noise.transforms)
    index = noise.transforms(i).index;
    params(index) = feval([noise.transforms(i).type 'Transform'], ...
              params(index), 'xtoa');
  end
end