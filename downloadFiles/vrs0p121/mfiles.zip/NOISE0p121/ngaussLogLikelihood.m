function L = ngaussLogLikelihood(noise, mu, varsigma, y)

% NGAUSSLOGLIKELIHOOD Log-likelihood of data under noiseless Gaussian noise model.
%
% L = ngaussLogLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.121





L = gaussianLogLikelihood(noise, mu, varsigma, y);
