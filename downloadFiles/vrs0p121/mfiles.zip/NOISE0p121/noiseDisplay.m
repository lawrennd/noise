function noiseDisplay(noise)

% NOISEDISPLAY Display the parameters of the noise model.
%
% noiseDisplay(noise)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Thu May  5 16:01:42 2005
% NOISE toolbox version 0.121



feval([noise.type 'NoiseDisplay'], noise)