function h = gaussianNoisePointPlot(noise, X, y, ...
                              fontName, fontSize, ...
                              markerSize, lineWidth);

% GAUSSIANNOISEPOINTPLOT Plot the data-points for ordered categorical noise model.
%
% h = gaussianNoisePointPlot(noise, X, y, ...
%                               fontName, fontSize, ...
%                               markerSize, lineWidth);

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Thu Jan 20 02:07:15 2005
% NOISE toolbox version 0.121



h = plot3(X(:, 1), X(:, 2), y, 'r.', 'erasemode', 'xor',  'markerSize', markerSize, 'linewidth', lineWidth);

minVals = min([X y]);
maxVals = max([X y]);

spans = maxVals - minVals;
gaps = spans*.05;

prop = {'xlim', 'ylim', 'zlim'};
for i = 1:3
  set(gca, prop{i}, [minVals(i)-gaps(i) maxVals(i)+gaps(i)]);
end
hold on