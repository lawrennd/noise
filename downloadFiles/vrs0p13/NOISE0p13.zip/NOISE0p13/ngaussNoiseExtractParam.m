function [params, names] = ngaussNoiseExtractParam(noise)

% NGAUSSNOISEEXTRACTPARAM Extract parameters from noiseless Gaussian noise model.
%
% [params, names] = ngaussNoiseExtractParam(noise)
%

% Copyright (c) 2005 Neil D. Lawrence
% ngaussNoiseExtractParam.m version 1.2





params = [noise.bias];


if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
end