function [g, nu] = noiseUpdateNuG(noise, mu, varSigma, y);

% NOISEUPDATENUG Update nu and g for a given noise model.
%
% [g, nu] = noiseUpdateNuG(noise, mu, varSigma, y);
%

% Copyright (c) 2005 Neil D. Lawrence
% noiseUpdateNuG.m version 1.4



if noise.updateNuG
  % The noise model has it's own code for site updates.
  fhandle = str2func([noise.type 'NoiseNuG']);
  [g, nu] = fhandle(noise, mu, varSigma, y);
else
  % Use the standard (general) code.
  fhandle = str2func([noise.type 'NoiseGradVals']);
  [g, dlnZ_dvs] = fhandle(noise, mu, varSigma, y);
  nu = g.*g - 2*dlnZ_dvs;
  nu(find(abs(nu) < eps)) = eps;
end

