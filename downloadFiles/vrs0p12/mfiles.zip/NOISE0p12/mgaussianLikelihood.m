function L = mgaussianLikelihood(noise, mu, varsigma, y)

% MGAUSSIANLIKELIHOOD Likelihood of data under Variable variance Gaussian noise model.
%
% L = mgaussianLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12






N = size(y, 1);
D = size(y, 2);
for i = 1:D
  varsigma(:, i) = varsigma(:, i) + noise.sigma2(i);
  mu(:, i) = mu(:, i) + noise.bias(i);
end
arg = (mu - y)./sqrt(varsigma);

L = (2*pi*varsigma).^(-1/2).*exp( - .5*arg.*arg);

% Set likelihood of unlabelled points to 1.
L(find(isnan(y)) = 1;