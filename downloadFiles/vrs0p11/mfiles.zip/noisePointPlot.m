function noisePointPlot(noise, X, y,  ...
                        fontName, fontSize, ...
                        markerSize, lineWidth)

% NOISEPOINTPLOT 
%
% noisePointPlot(noise, X, y,  ...
%                         fontName, fontSize, ...
%                         markerSize, lineWidth)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 16 08:49:38 2004
% NOISE toolbox version 0.11



feval([noise.type 'NoisePointPlot'], noise, X, y, ...
      fontName, fontSize, ...
      markerSize, lineWidth);

set(gca, 'fontname', fontName, 'fontsize', fontSize);