function h = noisePointPlot(noise, X, y,  ...
                        fontName, fontSize, ...
                        markerSize, lineWidth)

% NOISEPOINTPLOT 
%
% h = noisePointPlot(noise, X, y,  ...
%                         fontName, fontSize, ...
%                         markerSize, lineWidth)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Thu Jan 20 02:06:47 2005
% NOISE toolbox version 0.121



h = feval([noise.type 'NoisePointPlot'], noise, X, y, ...
      fontName, fontSize, ...
      markerSize, lineWidth);

set(gca, 'fontname', fontName, 'fontsize', fontSize);