function cmpndNoiseDisplay(noise)

% CMPNDNOISEDISPLAY Display the parameters of the compound noise model.
%
%	Description:
%	cmpndNoiseDisplay(noise)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	cmpndNoiseDisplay.m version 1.2




for i = 1:length(noise.comp)
  noiseDisplay(noise.comp{i});
end