function [nu, g] = orderedNoiseUpdateParams(noise, mu, varsigma, y, index)

% ORDEREDNOISEUPDATEPARAMS Update parameters for ordered categorical noise model.
%
% [nu, g] = orderedNoiseUpdateParams(noise, mu, varsigma, y, index)
%

% Copyright (c) 2005 Neil D. Lawrence
% orderedNoiseUpdateParams.m version 1.2





[g, dlnZ_dvs] = orderedNoiseGradVals(noise, mu(index, :), ...
                                            varsigma(index, :), ...
                                            y(index, :));

nu = g.*g - 2*dlnZ_dvs;