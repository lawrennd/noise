function L = cmpndLogLikelihood(noise, mu, varsigma, y)

% CMPNDLOGLIKELIHOOD Log-likelihood of data under compound noise model.
%
% L = cmpndLogLikelihood(noise, mu, varsigma, y)
%

% Copyright (c) 2005 Neil D. Lawrence
% cmpndLogLikelihood.m version 1.2





L = 0;
for i = 1:length(noise.comp)
  L = L + noiseLogLikelihood(noise.comp{i}, ...
			     mu(:, i), ...
			     varsigma(:, i), ...
			     y(:, i));
end