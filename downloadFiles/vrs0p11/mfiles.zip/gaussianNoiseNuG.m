function [g, nu] = gaussianNoiseNuG(noise, mu, varSigma, y)

% GAUSSIANNOISENUG Update nu and g parameters associated with Gaussian noise model.
%
% [g, nu] = gaussianNoiseNuG(noise, mu, varSigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11






D = size(y, 2);
nu = 1./(noise.sigma2+varSigma);
g = zeros(size(nu));
for i = 1:D
  g(:, i) = y(:, i) - mu(:, i) - ...
      noise.bias(i);
end
g = g.*nu;
