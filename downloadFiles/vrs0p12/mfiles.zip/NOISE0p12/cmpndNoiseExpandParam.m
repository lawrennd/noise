function noise = cmpndNoiseExpandParam(noise, params)

% CMPNDNOISEEXPANDPARAM Expand probit noise structure from param vector.
%
% noise = cmpndNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





params = params*noise.paramGroups';
startVal = 1;
endVal = 0;
for i = 1:length(noise.comp)
  endVal = endVal + noise.comp{i}.nParams;
  noise.comp{i} = noiseExpandParam(noise.comp{i}, params(1, startVal:endVal));
  startVal = endVal + 1;
end
