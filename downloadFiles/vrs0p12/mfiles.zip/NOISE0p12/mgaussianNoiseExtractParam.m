function [params, names] = mgaussianNoiseExtractParam(noise)

% MGAUSSIANNOISEEXTRACTPARAM Extract parameters from Variable variance Gaussian noise model.
%
% [params, names] = mgaussianNoiseExtractParam(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12






params = [noise.bias noise.sigma2];


if nargout > 1
  for i = 1:noise.numProcess
    names{i} = ['bias ' num2str(i)];
  end
  for i = noise.numProcess+1:2*noise.numProcess
    names{i} = ['sigma^2 ' num2str(i)];
  end
end