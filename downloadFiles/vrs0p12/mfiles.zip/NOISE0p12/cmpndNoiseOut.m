function y = cmpndNoiseOut(noise, mu, varsigma)

% CMPNDNOISEOUT Output from compound noise model.
%
% y = cmpndNoiseOut(noise, mu, varsigma)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





y = zeros(size(mu));
for i = 1:length(noise.comp)
  y(:, i) = feval([noise.comp{i}.type 'NoiseOut'], ...
                noise.comp{i},...
                mu(:, i), ...
                varsigma(:, i));
end

