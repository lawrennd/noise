function noiseDisplay(noise)

% NOISEDISPLAY Display the parameters of the noise model.
%
% noiseDisplay(noise)
%

% Copyright (c) 2005 Neil D. Lawrence
% noiseDisplay.m version 1.4



fhandle = str2func([noise.type 'NoiseDisplay']);
fhandle(noise);