function noise = ngaussNoiseExpandParam(noise, params)

% NGAUSSNOISEEXPANDPARAM Expand noiseless Gaussian noise model's structure from param vector.
%
% noise = ngaussNoiseExpandParam(noise, params)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.11





noise.bias = params(1:end);