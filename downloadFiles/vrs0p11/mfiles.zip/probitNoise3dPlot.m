function probitNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% PROBITNOISE3DPLOT Draw a 3D or contour plot for the probit.
%
% probitNoise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Wed Jun 16 09:10:49 2004
% NOISE toolbox version 0.11



CZ = cumGaussian((CZ + noise.bias)./sqrt(CZVar));
feval(plotType, CX, CY, CZ, varargin{:});

