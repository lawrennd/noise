function L = noiseLikelihood(noise, mu, varsigma, y);

% NOISELIKELIHOOD Return the likelihood for each point under the noise model.
%
% L = noiseLikelihood(noise, mu, varsigma, y);

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Tue Feb 22 16:34:38 2005
% NOISE toolbox version 0.121



L = feval([noise.type 'Likelihood'], noise, mu, varsigma, y);
