function g = noiseGradX(noise, mu, varsigma, dmu, dvs, y);

% NOISEGRADX Returns the gradient of the log-likelihood wrt x.
%
% g = noiseGradX(noise, mu, varsigma, dmu, dvs, y);

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.3, Mon Jun 21 08:58:26 2004
% NOISE toolbox version 0.12



[dlnZ_dmu, dlnZ_dvs] = noiseGradVals(noise, mu, varsigma, y);
g = dlnZ_dmu*dmu' + dlnZ_dvs*dvs';
