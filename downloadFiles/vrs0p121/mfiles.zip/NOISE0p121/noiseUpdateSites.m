function [m, beta] = noiseUpdateSites(noise, g, nu, mu, varSigma, y);

% NOISEUPDATESITES Update site parameters for a given noise model.
%
% [m, beta] = noiseUpdateSites(noise, g, nu, mu, varSigma, y);

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Tue Feb 22 16:31:33 2005
% NOISE toolbox version 0.121



if noise.updateSites
  % The noise model has it's own code for site updates.
  [m, beta] = ...
      feval([noise.type 'NoiseSites'], noise, ...
            g, nu,  mu, varSigma, y);
else
  % Use the standard code.
  beta = nu./(1-nu.*varSigma);
  m = mu + g./nu;
end
