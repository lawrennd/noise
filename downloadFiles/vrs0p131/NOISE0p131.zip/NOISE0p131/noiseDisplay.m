function noiseDisplay(noise. varargin)

% NOISEDISPLAY Display the parameters of the noise model.
%
%	Description:
%	noiseDisplay(noise. varargin)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	noiseDisplay.m version 1.5


fhandle = str2func([noise.type 'NoiseDisplay']);
fhandle(noise);