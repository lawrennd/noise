function noiseDisplay(noise)

% NOISEDISPLAY Display the parameters of the noise model.
%
% noiseDisplay(noise)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





feval([noise.type 'NoiseDisplay'], noise)