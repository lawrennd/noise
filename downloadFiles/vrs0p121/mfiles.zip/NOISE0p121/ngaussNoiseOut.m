function y = ngaussNoiseOut(noise, mu, varsigma)

% NGAUSSNOISEOUT Ouput from noiseless Gaussian noise model.
%
% y = ngaussNoiseOut(noise, mu, varsigma)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Mon Jul 26 15:39:38 2004
% NOISE toolbox version 0.121



y = gaussianNoiseOut(noise, mu, varsigma);