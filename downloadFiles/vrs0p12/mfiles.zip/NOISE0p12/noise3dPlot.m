function noise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% NOISE3DPLOT Draw a 3D or contour plot for the relevant noise model.
%
% noise3dPlot(noise, plotType, CX, CY, CZ, CZVar, varargin)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Tue Jun 22 13:59:42 2004
% NOISE toolbox version 0.12



functionName = [noise.type 'Noise3dPlot'];
if exist(functionName) == 2
  feval(functionName, noise, plotType, CX, CY, CZ, CZVar, varargin{:});
end

