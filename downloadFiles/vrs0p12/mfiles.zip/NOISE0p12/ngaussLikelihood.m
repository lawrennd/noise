function L = ngaussLikelihood(noise, mu, varsigma, y)

% NGAUSSLIKELIHOOD Likelihood of data under noiseless Gaussian noise model.
%
% L = ngaussLikelihood(noise, mu, varsigma, y)

% Copyright (c) 2004 Neil D. Lawrence
% File version 1.2, Sat Jun 12 13:19:41 2004
% NOISE toolbox version 0.12





L = gaussianLikelihood(noise, mu, varsigma, y);