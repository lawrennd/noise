function noise = gaussianNoiseExpandParam(noise, params)

% GAUSSIANNOISEEXPANDPARAM Expand Gaussian noise structure from param vector.
%
% noise = gaussianNoiseExpandParam(noise, params)

% Copyright (c) 2005 Neil D. Lawrence
% File version 1.3, Wed Feb 23 11:40:32 2005
% NOISE toolbox version 0.121



noise.bias = params(1:end-1);
noise.sigma2 = params(end);